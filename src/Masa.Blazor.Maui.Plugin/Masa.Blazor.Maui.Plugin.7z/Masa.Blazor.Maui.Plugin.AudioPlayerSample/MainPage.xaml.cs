﻿namespace Masa.Blazor.Maui.Plugin.AudioPlayerSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}