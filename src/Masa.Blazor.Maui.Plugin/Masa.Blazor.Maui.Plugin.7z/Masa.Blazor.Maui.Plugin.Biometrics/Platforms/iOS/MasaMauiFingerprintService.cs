﻿namespace Masa.Blazor.Maui.Plugin.Biometrics
{
    // All the code in this file is only included on iOS.
    public static partial class MasaMauiFingerprintService
    {
    }
}