﻿namespace Masa.Blazor.Maui.Plugin.Biometrics
{
    // All the code in this file is included in all platforms.
    public static partial class MasaMauiFingerprintService
    {
    }
}