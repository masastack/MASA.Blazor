﻿namespace Masa.Blazor.Maui.Plugin.BiometricsSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}