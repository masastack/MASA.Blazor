﻿namespace Masa.Blazor.Maui.Plugin.BiometricsSample
{
    public partial class App : Microsoft.Maui.Controls.Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new MainPage();
        }
    }
}