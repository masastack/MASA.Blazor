﻿namespace Masa.Blazor.Maui.Plugin.Bluetooth
{
    // All the code in this file is only included on Mac Catalyst.
    public class PlatformClass1
    {
    }
}