﻿using System;

namespace Masa.Blazor.Maui.Plugin.Bluetooth
{
    // All the code in this file is only included on Tizen.
    public class PlatformClass1
    {
    }
}