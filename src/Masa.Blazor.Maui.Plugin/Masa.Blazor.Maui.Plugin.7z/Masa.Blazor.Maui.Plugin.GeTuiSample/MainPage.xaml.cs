﻿namespace Masa.Blazor.Maui.Plugin.GeTuiSample
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}